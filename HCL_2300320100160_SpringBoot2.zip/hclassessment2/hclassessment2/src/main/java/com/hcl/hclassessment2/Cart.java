package com.hcl.hclassessment2;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "carts")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_id")
    private Long cartId;

    // One-to-One relationship mapping to the Customer entity
    @OneToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    // Automatically sets the timestamp before the record is saved to the database
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    // Default No-Arg Constructor (Required by JPA)
    public Cart() {
    }

    // All-Args Constructor
    public Cart(Long cartId, Customer customer, LocalDateTime createdDate) {
        this.cartId = cartId;
        this.customer = customer;
        this.createdDate = createdDate;
    }

    // Getters and Setters
    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
}
